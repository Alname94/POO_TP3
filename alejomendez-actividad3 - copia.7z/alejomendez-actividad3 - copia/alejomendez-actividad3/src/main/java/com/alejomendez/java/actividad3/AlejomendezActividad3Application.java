package com.alejomendez.java.actividad3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlejomendezActividad3Application {

	public static void main(String[] args) {
		SpringApplication.run(AlejomendezActividad3Application.class, args);
	}

}
