package com.alejomendez.java.actividad3.controllers;

import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alejomendez.java.actividad3.models.entities.Detalle;
import com.alejomendez.java.actividad3.models.entities.Presupuesto;
import com.alejomendez.java.actividad3.services.DetalleService;
import com.alejomendez.java.actividad3.services.PresupuestoService;
import com.alejomendez.java.actividad3.services.RepuestoService;

@Controller
public class DetalleController {
    private final DetalleService detalleService;
    private final PresupuestoService presupuestoService;
    private final RepuestoService repuestoService;

    public DetalleController(DetalleService detalleService, PresupuestoService presupuestoService,
            RepuestoService repuestoService) {
        this.detalleService = detalleService;
        this.presupuestoService = presupuestoService;
        this.repuestoService = repuestoService;
    }

    // @PostMapping("/presupuesto/agregarRepuesto")
    // public String agregarRepuesto(@ModelAttribute("detalle") @RequestParam(value = "repuestoCodigo", required = true) int repuestoCodigo, @RequestParam(value = "presupuestoNumero", required = true) int presupuestoNumero, Model model) {
    //     Detalle detalle = new Detalle();
    //     try {
    //         detalleService.guardarDetalle(detalle);
    //         return "presupuesto-editar";
    //     } catch (SQLException e) {
    //         e.printStackTrace();
    //         model.addAttribute("error", "Error al agregar el repuesto: " + e.getMessage());
    //         System.out.println("error");
    //         return "/";
    //     }
    // }

    // public String agregarRepuesto(@RequestParam("repuestoCodigo") int repuestoCodigo,
    //     @RequestParam("presupuestoNumero") int presupuestoNumero, Model model) {
    //     try {
    //         Detalle detalle = new Detalle();
    //         detalle.setRepuestoCodigo(repuestoCodigo);
    //         detalle.setPresupuestoNumero(presupuestoNumero);
    //         detalleService.guardarDetalle(detalle);

    //         // Recargar datos para la vista
    //         Presupuesto presupuesto = presupuestoService.buscaPresupuestoPorNumero(presupuestoNumero);
    //         model.addAttribute("presupuesto", presupuesto);
    //         model.addAttribute("repuesto", repuestoCodigo);
    //         return "presupuesto-editar";

    //     } catch (SQLException e) {
    //         e.printStackTrace();
    //         model.addAttribute("error", "Error al agregar el repuesto: " + e.getMessage());
    //         return "presupuesto-editar";
    //     }
    // }

    
}
