package com.alejomendez.java.actividad3.controllers;

import java.sql.SQLException;
import java.util.List;
import java.util.PrimitiveIterator;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.alejomendez.java.actividad3.models.entities.Bicicleta;
import com.alejomendez.java.actividad3.models.entities.Cliente;
import com.alejomendez.java.actividad3.models.entities.Detalle;
import com.alejomendez.java.actividad3.models.entities.Presupuesto;
import com.alejomendez.java.actividad3.models.entities.Repuesto;
import com.alejomendez.java.actividad3.services.BicicletaService;
import com.alejomendez.java.actividad3.services.ClienteService;
import com.alejomendez.java.actividad3.services.DetalleService;
import com.alejomendez.java.actividad3.services.PresupuestoService;
import com.alejomendez.java.actividad3.services.RepuestoService;

@Controller
public class PresupuestoController {
    private final PresupuestoService presupuestoService;
    private final RepuestoService repuestoService;
    private final DetalleService detalleService;
    private final ClienteService clienteService;
    private final BicicletaService bicicletaService;

    public PresupuestoController(PresupuestoService presupuestoService, RepuestoService repuestoService,
            DetalleService detalleService, ClienteService clienteService, BicicletaService bicicletaService) {
        this.presupuestoService = presupuestoService;
        this.repuestoService = repuestoService;
        this.detalleService = detalleService;
        this.clienteService = clienteService;
        this.bicicletaService = bicicletaService;
    }    

    @GetMapping("/")
    public String home(Model model) {
        try {
            List<Presupuesto> presupuestos = presupuestoService.obtenerTodosLosPresupuestos();
            model.addAttribute("presupuestos", presupuestos);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorPresupuestos", "Error al cargar los presupuestos: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Ha ocurrido un error inesperado: " + e.getMessage());
        }
        return "index";
    }

    @GetMapping("/presupuesto/alta")
    public String altaPresupuestoForm(Model model) {
        model.addAttribute("presupuesto", new Presupuesto());
        try {
            List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
            List<Bicicleta> bicicletas = bicicletaService.obtenerTodasLasBicicletas();
            List<Repuesto> repuestos = repuestoService.obtenerTodosLosRepuestos();
            model.addAttribute("clientes", clientes);
            model.addAttribute("bicicletas", bicicletas);
            model.addAttribute("repuestos", repuestos); 
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorClientes", "Error al cargar los clientes: " + e.getMessage());
            model.addAttribute("errorBicicletas","Error al cargar las bicicletas: " + e.getMessage());
            model.addAttribute("errorRepuestos", "Error al cargar los repuestos: " + e.getMessage());
        }
        return "presupuesto-alta";
    }

    // @GetMapping("/presupuesto/alta")
    // public String altaPresupuestoForm(@RequestParam(value = "clienteId", required = false) Integer clienteId, Model model) throws SQLException {
    //     Presupuesto presupuesto = new Presupuesto();
    //     model.addAttribute("presupuesto", presupuesto);
    //     List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
    //     model.addAttribute("clientes", clientes);
    //     List<Bicicleta> bicicletas;
    //     if (clienteId != null) {
    //         bicicletas = bicicletaService.buscarBicicletaPorCliente(clienteId);
    //         model.addAttribute("presupuesto", presupuesto);
    //     } else {
    //         bicicletas = bicicletaService.obtenerTodasLasBicicletas();
    //     }
    //     model.addAttribute("bicicletas", bicicletas);
    //     // repuestos...
    // return "presupuesto-alta";
    // }

    @PostMapping("/presupuesto/guardar")
    public String guardarPresupuesto(@ModelAttribute("presupuesto") Presupuesto presupuesto, Model model) {
        try {
            presupuestoService.guardarPresupuesto(presupuesto);
            return "redirect:/";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al guardar el presupuesto: " + e.getMessage());
        }
        return "presupuesto-alta"; 
    }

    @GetMapping("/presupuestos/buscar")
    public String buscarPresupuestoPorNumero(@RequestParam(value="numero", required = false) Integer numero, Model model) {
        try {
            List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
            List<Bicicleta> bicicletas = bicicletaService.obtenerTodasLasBicicletas();
            model.addAttribute("clientes", clientes);
            model.addAttribute("bicicletas", bicicletas);
            if (numero != null && numero > 0) {
                Presupuesto presupuesto = presupuestoService.buscaPresupuestoPorNumero(numero);
                if (presupuesto != null) {
                    model.addAttribute("presupuesto", presupuesto);
                } else {
                    List<Presupuesto> presupuestos = presupuestoService.obtenerTodosLosPresupuestos();
                    model.addAttribute("presupuestos", presupuestos);
                    return "index";
                }
            } else {
                List<Presupuesto> presupuestos = presupuestoService.obtenerTodosLosPresupuestos();
                model.addAttribute("presupuestos", presupuestos);
                return "index";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al buscar el presupuesto: " + e.getMessage());
        }
        return "presupuesto-editar";
    }

    @GetMapping("/presupuesto/editar")
    public String editarPresupuesto(@RequestParam("numero") int numero, Model model) {
        try {
            Presupuesto presupuesto = presupuestoService.buscaPresupuestoPorNumero(numero);
            List<Cliente> clientes = clienteService.obtenerTodosLosClientes();
            List<Bicicleta> bicicletas = bicicletaService.obtenerTodasLasBicicletas();
            List<Repuesto> repuestos = repuestoService.obtenerTodosLosRepuestos();
            model.addAttribute("clientes", clientes);
            model.addAttribute("bicicletas", bicicletas);
            model.addAttribute("repuestos", repuestos);
            if(presupuesto !=null){
                model.addAttribute("presupuesto", presupuesto);
                return "presupuesto-editar";
            }else{
                return "redirect:/index";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorClientes", "Error al cargar los clientes: " + e.getMessage());
            model.addAttribute("errorBicicletas","Error al cargar las bicicletas: " + e.getMessage());
            model.addAttribute("errorRepuestos", "Error al cargar los presupuestos: " + e.getMessage());
            model.addAttribute("error", "Error al cargar el presupuesto para editar: " + e.getMessage());
            return "redirect:/index";
        }
    }

    @PostMapping("/presupuesto/actualizar")
    public String actualizarPresupuesto(@ModelAttribute("presupuesto") Presupuesto presupuesto, Model model) {
        try {
            presupuestoService.guardarPresupuesto(presupuesto);
            return "redirect:/";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al actualizar el presupuesto: " + e.getMessage());
            return "presupuesto/editar";
        }
    }

    @GetMapping("/presupuesto/eliminar")
    public String eliminarPresupuesto(@RequestParam("numero") int numero, Model model) {
        try {
            presupuestoService.eliminarPresupuesto(numero);
            return "redirect:/";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al eliminar el presupuesto: " + e.getMessage());
            try {
                model.addAttribute("", presupuestoService.obtenerTodosLosPresupuestos());
            } catch (SQLException ex) {
                model.addAttribute("error", "Error al cargar los presupuestos después de la eliminacién fallida: " + ex.getMessage());
            }
            return "index";   
        }
    }
    //ESTE FUNCIONA
    // @PostMapping("/presupuesto/agregarRepuesto")
    // public String agregarRepuesto(@RequestParam("repuestoCodigo") int repuestoCodigo,
    //     @RequestParam("presupuestoNumero") int presupuestoNumero, Model model) {
    //     try {
    //         Detalle detalle = new Detalle(presupuestoNumero, repuestoCodigo);
    //         detalleService.guardarDetalle(detalle);

    //         // Recargar datos para la vista
    //         Presupuesto presupuesto = presupuestoService.buscaPresupuestoPorNumero(presupuestoNumero);
    //         List<Repuesto> repuestos = repuestoService.obtenerTodosLosRepuestos();
    //         model.addAttribute("presupuesto", presupuesto);
    //         model.addAttribute("repuestos", repuestos);
    //         return "presupuesto-editar";
    //     } catch (SQLException e) {
    //         e.printStackTrace();
    //         model.addAttribute("error", "Error al agregar el repuesto: " + e.getMessage());
    //         return "index";
    //     }
    // }

    // @PostMapping("/presupuesto/addRepuesto")
    // public String agregarRepuesto(@RequestParam(value= "numero", required = false) Integer numero, @RequestParam(value= "codigo", required = false) Integer codigo, Model model) {
    //     try {
    //         Presupuesto presupuesto = presupuestoService.buscaPresupuestoPorNumero(numero);
    //         Repuesto repuesto = repuestoService.buscarRepuestoPorCodigo(codigo);
    //         model.addAttribute("presupuesto", presupuesto);
    //         model.addAttribute("repuesto", repuesto);
    //         Detalle detalle = new Detalle(presupuesto.getNumero(), repuesto.getCodigo());
    //         model.addAttribute("detalle", detalle);
    //         detalleService.guardarDetalle(detalle);
    //     } catch (SQLException e) {
    //         e.printStackTrace();
    //         model.addAttribute("error", "Error al agregar el repuesto: " + e.getMessage());
    //     }
    //     return "presupuesto-alta";
    // }

    //Post‑Redirect‑Get (PRG)
    //Controlador – método POST
    @PostMapping("/presupuesto/agregarRepuesto")
    public String agregarRepuesto(@RequestParam int repuestoCodigo, @RequestParam int presupuestoNumero, RedirectAttributes ra, Model model) throws SQLException {
        try {
            Detalle detalle = new Detalle(presupuestoNumero, repuestoCodigo);
            detalleService.guardarDetalle(detalle);
            ra.addAttribute("numero", presupuestoNumero);
            return "redirect:/presupuesto/editar";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al agregar el repuesto: " + e.getMessage());
            return "index"; 
        }
    }



}
