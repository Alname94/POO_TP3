package com.alejomendez.java.actividad3.entities;

public class Detalle {
    private int presupuestoNumero;
    private int repuestoCodigo;
}
