package com.alejomendez.java.actividad3.entities;

public class Repuesto {
    private int codigo;
    private String producto;
    private String marca;
    private String color;
    private double precioVenta;
    private double precioCosto;
    private int stock;
}
