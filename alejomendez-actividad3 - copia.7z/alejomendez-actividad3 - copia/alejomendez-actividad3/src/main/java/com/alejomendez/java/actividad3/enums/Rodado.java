package com.alejomendez.java.actividad3.enums;

import lombok.Getter;

@Getter
public enum Rodado {
    RODADO_14(14),
    RODADO_16(16),
    RODADO_20(20),
    RODADO_22(22),
    RODADO_24(24),
    RODADO_26(26),
    RODADO_27(27.5),
    RODADO_28(28),
    RODADO_29(29);

    Rodado(double i) {
        //TODO Auto-generated constructor stub
    }

   
}
