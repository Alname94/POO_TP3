package com.alejomendez.java.actividad3.enums;

public enum Rodado {
    R14(14),
    R16(16),
    R20(20),
    R22(22),
    R24(24),
    R26(26),
    R27(27.5),
    R28(28),
    R29(29);

    private final double numero;

    Rodado(double numero) {
        this.numero = numero;
    }

    public double getNumero() {
        return numero;
    }

    public static Rodado getRodado(double numero) {
        for (Rodado r : values()) {
            if (r.numero == numero) {
                return r;
            }
        }
        throw new IllegalArgumentException("Rodado inválido: " + numero);
    }

   
}
