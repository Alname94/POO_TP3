package com.alejomendez.java.actividad3.models.enums;

public enum Rodado {
    R14("14"),
    R16("16"),
    R20("20"),
    R22("22"),
    R24("24"),
    R26("26"),
    R27_5("27.5"),
    R28("28"),
    R29("29");

    private final String code;

    Rodado(String code) { this.code = code; }

    public String getCode() { return code; }

    public static Rodado fromCode(String code) {
        for (Rodado r : values()) {
            if (r.code.equals(code)) return r;
        }
        throw new IllegalArgumentException("Rodado inválido: " + code);
    }

    //este operador ternario verifica si el numero es entero o double, ya que si el rodado elegido es 28 y no se hace la especificación de que es un int, Java lo toma como 28.0 y ese valor no coincide con el 28 de la BD, generando una Exception.
    //Utilizando este método, al crear una instancia de Bicicleta, podemos pasar como parámetro del rodado tanto un int(28) como un double(27.5)
    public static Rodado obtenerRodado(double numero) {
        return fromCode(numero % 1 == 0 ? String.valueOf((int) numero) : String.valueOf(numero));
    }
    
    // private final double numero;

    // Rodado(double numero) {
    //     this.numero = numero;
    // }

    // public double getNumero() {
    //     return numero;
    // }

    // public static Rodado obtenerRodado(double numero) {
    //     for (Rodado r : values()) {
    //         if (r.numero == numero) {
    //             return r;
    //         }
    //     }
    //     throw new IllegalArgumentException("Rodado inválido: " + numero);
    // }   
}
