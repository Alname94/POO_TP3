package com.alejomendez.java.actividad3.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.alejomendez.java.actividad3.entities.Cliente;

public interface I_ClienteRepository {
    void create(Cliente cliente) throws SQLException;
    Cliente findById(int id) throws SQLException;
    List<Cliente> findAll() throws SQLException;
    int update(Cliente cliente) throws SQLException;
    int delete(int id) throws SQLException;
    List<Cliente> findByPresupuesto(int numero) throws SQLException;
    List<Cliente> findByBicicleta(int id) throws SQLException;  
}   
