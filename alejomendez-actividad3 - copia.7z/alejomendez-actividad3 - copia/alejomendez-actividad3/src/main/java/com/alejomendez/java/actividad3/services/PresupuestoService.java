package com.alejomendez.java.actividad3.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.alejomendez.java.actividad3.models.entities.Presupuesto;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_PresupuestoRepository;

@Service
public class PresupuestoService {
    private final I_PresupuestoRepository presupuestoRepository;

    public PresupuestoService(I_PresupuestoRepository presupuestoRepository) {
        this.presupuestoRepository = presupuestoRepository;
    }

    /**
     * Obtiene una lista de todos los presupuestos
     * @return
     * @throws SQLException
     */
    public List<Presupuesto> obtenerTodosLosPresupuestos() throws SQLException {
        return presupuestoRepository.findAll();
    }

    /**
     * Guarda un presupuesto o lo actualiza si el presupuesto ya existe
     * @param presupuesto
     * @return
     * @throws SQLException
     */
    public Presupuesto guardarPresupuesto(Presupuesto presupuesto) throws SQLException {
        if(presupuesto.getNumero()!=0){
            presupuestoRepository.update(presupuesto);
        }else{
            presupuestoRepository.create(presupuesto);
        }
        return presupuesto;
    }
    
    /**
     * Busca un presupuesto por su numero
     * @param numero
     * @return
     * @throws SQLException
     */
    public Presupuesto buscaPresupuestoPorNumero(int numero) throws SQLException {
        return presupuestoRepository.findByNumero(numero);
    }

    /**
     * Elimina un presupuesto por numero
     * @param numero
     * @return
     * @throws SQLException
     */
    public int eliminarPresupuesto(int numero) throws SQLException {
        return presupuestoRepository.delete(numero);
    }

    /**
     * Lista los presupuestos pertenecientes a una bicicleta
     * @param bicicletaId
     * @return
     * @throws SQLException
     */
    public List<Presupuesto> buscarPresupuestoPorBicicleta(int bicicletaId) throws SQLException {
        return presupuestoRepository.findByBicicleta(bicicletaId);
    }

    /**
     * Lista los presupuestos pertenecientes a un cliente
     * @param clienteId
     * @return
     * @throws SQLException
     */
    public List<Presupuesto> buscarPresupuestoPorCliente(int clienteId) throws SQLException {
        return presupuestoRepository.findByCliente(clienteId);
    }
}
