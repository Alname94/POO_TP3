package com.alejomendez.java.actividad3.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alejomendez.java.actividad3.models.entities.Presupuesto;
import com.alejomendez.java.actividad3.models.entities.Repuesto;
import com.alejomendez.java.actividad3.services.DetalleService;
import com.alejomendez.java.actividad3.services.PresupuestoService;
import com.alejomendez.java.actividad3.services.RepuestoService;

@Controller
public class PresupuestoController {
    private final PresupuestoService presupuestoService;
    private final RepuestoService repuestoService;
    private final DetalleService detalleService;

    public PresupuestoController(PresupuestoService presupuestoService, RepuestoService repuestoService,
            DetalleService detalleService) {
        this.presupuestoService = presupuestoService;
        this.repuestoService = repuestoService;
        this.detalleService = detalleService;
    }    

    @GetMapping("/")
    public String home(Model model) {
        try {
            List<Presupuesto> presupuestos = presupuestoService.obtenerTodosLosPresupuestos();
            model.addAttribute("presupuestos", presupuestos);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar los presupuestos: " + e.getMessage());
        } catch (Exception e) { // Capturar otras posibles excepciones de la capa de servicio
            e.printStackTrace();
            model.addAttribute("error", "Ha ocurrido un error inesperado: " + e.getMessage());
        }
        return "index";
    }

    @GetMapping("/presupuesto/alta")
    public String altaPresupuestoForm(Model model) {
        model.addAttribute("presupuesto", new Presupuesto());
        try {
            List<Repuesto> repuestos = repuestoService.obtenerTodosLosRepuestos();
            model.addAttribute("repuestos", repuestos); 
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar los repuestos: " + e.getMessage());
        }
        return "presupuesto-alta";
    }

    // @PostMapping("/presupuesto/addRepuesto")
    // public String agregarRepuesto(@RequestParam(value= "numero", required = false) Integer numero, @RequestParam(value= "codigo", required = false) Integer codigo, Model model) {
    //     try {
    //         List<Repuesto> repuestos;
    //         if(codigo!=0 && codigo!=null){
                
    //         }
    //     } catch (Exception e) {
    //         // TODO: handle exception
    //     }
    //     return "presupuesto-alta";
    // }



}
