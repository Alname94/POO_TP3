package com.alejomendez.java.actividad3.entities;

import java.time.LocalDate;

import com.alejomendez.java.actividad3.enums.Rodado;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Bicicleta {
    private int id;
    private int idCliente;
    private String marca;
    private String modelo;
    private String color;
    private Rodado rodado;
    private LocalDate fechaIngreso;
    private LocalDate fechaEgreso;

}
