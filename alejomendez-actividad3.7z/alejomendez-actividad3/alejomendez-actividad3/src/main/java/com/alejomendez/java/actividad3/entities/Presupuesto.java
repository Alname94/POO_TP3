package com.alejomendez.java.actividad3.entities;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Presupuesto {
    private int numero;
    private LocalDate fecha;
    private int clienteId;
    private int bicicletaId;
    private double valorTotal;
    private String detalle;
}
