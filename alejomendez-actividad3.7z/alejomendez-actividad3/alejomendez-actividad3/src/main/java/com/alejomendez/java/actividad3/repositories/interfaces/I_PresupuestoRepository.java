package com.alejomendez.java.actividad3.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.alejomendez.java.actividad3.entities.Presupuesto;

public interface I_PresupuestoRepository {
    void create(Presupuesto presupuesto) throws SQLException;
    Presupuesto findByNumero(int numero) throws SQLException;
    List<Presupuesto> findAll() throws SQLException;
    int update(Presupuesto presupuesto) throws SQLException;
    int delete(int numero) throws SQLException;
    List<Presupuesto> findByBicicleta(int bicicletaId) throws SQLException;
    List<Presupuesto> findByCliente(int clienteId) throws SQLException;
}
