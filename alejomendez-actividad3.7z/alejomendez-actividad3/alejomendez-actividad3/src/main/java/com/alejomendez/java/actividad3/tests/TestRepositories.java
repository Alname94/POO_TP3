package com.alejomendez.java.actividad3.tests;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.alejomendez.java.actividad3.models.entities.Bicicleta;
import com.alejomendez.java.actividad3.models.entities.Cliente;
import com.alejomendez.java.actividad3.models.entities.Detalle;
import com.alejomendez.java.actividad3.models.entities.Presupuesto;
import com.alejomendez.java.actividad3.models.entities.Repuesto;
import com.alejomendez.java.actividad3.models.enums.Rodado;
import com.alejomendez.java.actividad3.models.repositories.BicicletaRepository;
import com.alejomendez.java.actividad3.models.repositories.ClienteRepository;
import com.alejomendez.java.actividad3.models.repositories.DetalleRepository;
import com.alejomendez.java.actividad3.models.repositories.PresupuestoRepository;
import com.alejomendez.java.actividad3.models.repositories.RepuestoRepository;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_BicicletaRepository;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_ClienteRepository;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_DetalleRepository;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_PresupuestoRepository;
import com.alejomendez.java.actividad3.models.repositories.interfaces.I_RepuestoRepository;

@SpringBootApplication(scanBasePackages = "com.alejomendez.java.actividad3")
public class TestRepositories {
    public static void main(String[] args) {

        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {
            I_ClienteRepository clienteRepository = context.getBean(ClienteRepository.class);
            I_BicicletaRepository bicicletaRepository = context.getBean(BicicletaRepository.class);
            I_PresupuestoRepository presupuestoRepository = context.getBean(PresupuestoRepository.class);
            I_RepuestoRepository repuestoRepository = context.getBean(RepuestoRepository.class);
            I_DetalleRepository detalleRepository = context.getBean(DetalleRepository.class);

            //Pruebas de clientes

            //Test 1: Crear cliente
            System.out.println("\n>>> Test 1: Creando un cliente");
            Cliente nuevoCliente = new Cliente(0, "Alejo", "Mendez", "32323245", "1143454565", null);
            clienteRepository.create(nuevoCliente);
            if(nuevoCliente.getId()>0){
                System.out.println(" ## Cliente creado correctamente con el id " + nuevoCliente.getId());
                System.out.println(nuevoCliente);
            }else {
                System.err.println(" ¡¡ ERROR - no se pudo crear al cliente !!");
            }

            //Test 2: Buscar un Cliente por ID (existente)
            System.out.println("\n>>> Test 2: Buscando cliente por ID " + nuevoCliente.getId() + "...");
            Cliente clienteEncontrado = clienteRepository.findById(nuevoCliente.getId());
            if(clienteEncontrado!=null){
                System.out.println(" ## Cliente encontrado: " + clienteEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el cliente con el ID  " + nuevoCliente.getId() + " !!");
            }

            //Test 3: Buscar un Cliente por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando Cliente con ID 999 (inexistente)");
            Cliente cliente = clienteRepository.findById(999);
            if (cliente != null){
                System.out.println(" ## Cliente encontrado: " + cliente);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el cliente con ID 999 !!");
            }

            //Test 4: Actualizar un Cliente
            System.out.println("\n>>> Test 4: Actualizando Cliente " + nuevoCliente.getId() + "...");
            nuevoCliente.setNombre("Ricardo Horacio");
            int filasAfectadas = clienteRepository.update(nuevoCliente);
            if(filasAfectadas==1){
                System.out.println(" ## Cliente " + nuevoCliente.getId() + " actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + clienteRepository.findById(nuevoCliente.getId()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar al cliente !!");
            }

            //Test 5: Listar todos los clientes
            System.out.println("\n>>> Test 5: Listando todos los clientes...");
            List<Cliente> clientesTodos = clienteRepository.findAll();
            if(!clientesTodos.isEmpty()){
                System.out.println(" ## Clientes encontrados: " + clientesTodos.size());
                clientesTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron clientes");
            }

            //Test 6: Eliminar un cliente
            System.out.println("\n>>> Test 6: Eliminando Cliente " + nuevoCliente.getId() + "...");
            int filasAfectadasDelete = clienteRepository.delete(nuevoCliente.getId());
            if(filasAfectadasDelete==1){
                System.out.println(" ## Cliente " + nuevoCliente.getId() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + clienteRepository.findById(nuevoCliente.getId()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar al cliente !!");
            }

            //Test 7: Buscar un cliente por presupuesto (existente)
            System.out.println("\n>>> Test 7: Buscando cliente por presupuesto ...");
            Cliente clientePresupuesto = clienteRepository.findByPresupuesto(2);
            if(clientePresupuesto!=null){
                System.out.println(" ## Cliente encontrado: " + clientePresupuesto);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró cliente !!");
            }

            //Test 8: Buscar un Cliente por bicicleta (existente)
            System.out.println("\n>>> Test 8: Buscando cliente por bicicleta ...");
            Cliente clienteBicicleta = clienteRepository.findByBicicleta(10);
            if(clienteBicicleta!=null){
                System.out.println(" ## Cliente encontrado: " + clienteBicicleta);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró cliente !!");
            }

            //Pruebas para Bicicletas

            //Test 9: Crear una nueva bicicleta
            System.out.println("\n>>> Test 9: Creando una bicicleta");
            Bicicleta nuevaBicicleta = new Bicicleta(0, 22, "Cavalera", "Alteq", "Rojo", Rodado.obtenerRodado(27.5), LocalDate.now(), null);
            if(clienteRepository.findById(nuevaBicicleta.getIdCliente())!=null){
                bicicletaRepository.create(nuevaBicicleta);
            }else {
                System.err.println("El id del cliente no existe");
            }            
            if(nuevaBicicleta.getId()>0){
                System.out.println(" ## Bicicleta creada correctamente con el id " + nuevaBicicleta.getId());
                System.out.println(nuevaBicicleta);
            }else {
                System.err.println(" ¡¡ ERROR - no se pudo crear la bicicleta !!");
            }

            //Test 10: Buscar una bicicleta por ID (Existente)
            System.out.println("\n>>> Test 10: Buscando bicicleta por ID " + nuevaBicicleta.getId() + "...");
            Bicicleta bicicletaEncontrada = bicicletaRepository.findById(nuevaBicicleta.getId());
            if(bicicletaEncontrada!=null){
                System.out.println(" ## Bicicleta encontrada: " + bicicletaEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró la bicicleta con el ID " + nuevaBicicleta.getId() + " !!");
            }

            //Test 11: Buscar una bicicleta por ID (Inexistente)
            System.out.println("\n>>> Test 11: Buscando bicicleta por ID...");
            Bicicleta bicicletaNoEncontrada = bicicletaRepository.findById(999);
            if(bicicletaNoEncontrada!=null){
                System.out.println(" ## Bicicleta encontrada: " + bicicletaNoEncontrada);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró la bicicleta con el ID 999 !!");
            }

            // //Test 12: Listar todas las bicicletas
            System.out.println("\n>>> Test 12: Listando todas las bicicletas...");
            List<Bicicleta> bicicletasTodas = bicicletaRepository.findAll();
            if(!bicicletasTodas.isEmpty()){
                System.out.println(" ## Bicicletas encontradas: " + bicicletasTodas.size());
                bicicletasTodas.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron bicicletas !!");
            }

            //Test 13: Actualizar una bicicleta
            System.out.println("\n>>> Test 13: Actualizando bicicleta " + nuevaBicicleta.getId() + "...");
            nuevaBicicleta.setFechaEgreso(LocalDate.of(2025, 06, 22));
            filasAfectadas = bicicletaRepository.update(nuevaBicicleta);
            if(filasAfectadas==1){
                System.out.println(" ## Bicicleta " + nuevaBicicleta.getId() + " actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + nuevaBicicleta);
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar la bicicleta !!");
            }

            //Test 14: Eliminar una bicicleta
            System.out.println("\n>>> Test 14: Eliminando Bicicleta " + nuevaBicicleta.getId() + "...");
            filasAfectadasDelete = bicicletaRepository.delete(nuevaBicicleta.getId());
            if(filasAfectadasDelete==1){
                System.out.println(" ## Bicicleta " + nuevaBicicleta.getId() + " eliminada correctamente");
                System.out.println("Verificando eliminación: " + bicicletaRepository.findById(nuevaBicicleta.getId()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar la bicicleta !!");
            }

            //Test 15: Buscar una bicicleta por presupuesto (existente)
            System.out.println("\n>>> Test 15: Buscando bicicleta por presupuesto...");
            Bicicleta bicicletaPresupuesto = bicicletaRepository.findByPresupuesto(2);
            if(bicicletaPresupuesto!=null){
                System.out.println(" ## Bicicleta encontrada: " + bicicletaPresupuesto);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró bicicleta !!");
            }

            //Test 16: Buscar bicicletas por cliente (existente)
            System.out.println("\n>>> Test 16: Buscando bicicletas por cliente...");
            List<Bicicleta> bicicletasCliente = bicicletaRepository.findByCliente(3);
            if(!bicicletasCliente.isEmpty()){
                System.out.println(" ## Bicicletas encontradas: " + bicicletasCliente.size());
                bicicletasCliente.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron bicicletas !!");
            }


            //Pruebas para Presuspuesto

            //Test 17: Crear un presupuesto
            System.out.println("\n>>> Test 17: Creando un presupuesto");
            Presupuesto nuevoPresupuesto = new Presupuesto(0, LocalDate.now(), 3 , 3 , 20000, null);
            presupuestoRepository.create(nuevoPresupuesto);
            if(nuevoPresupuesto.getNumero()>0){
                System.out.println(" ## Presupuesto creado correctamente con el numero " + nuevoPresupuesto.getNumero());
                System.out.println(nuevoPresupuesto);
            }else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el presupuesto !!");
            }

            //Test 18: Buscar un presupuesto por número (existente)
            System.out.println("\n>>> Test 18: Buscando presupuesto por número " + nuevoPresupuesto.getNumero() + "...");
            Presupuesto presupuestoEncontrado = presupuestoRepository.findByNumero(nuevoPresupuesto.getNumero());
            if(presupuestoEncontrado!=null){
                System.out.println(" ## Presupuesto encontrado: " + presupuestoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el presupuesto con el número " + nuevoPresupuesto.getNumero() + " !!");
            }

            //Test 19: Listar todos los presupuestos
            System.out.println("\n>>> Test 19: Listando todos los presupuestos...");
            List<Presupuesto> presupuestosTodos = presupuestoRepository.findAll();
            if(!presupuestosTodos.isEmpty()){
                System.out.println(" ## Presupuestos encontrados: " + presupuestosTodos.size());
                presupuestosTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron presupuestos !!");
            }

            //Test 20: Actualizar un presupuesto
            System.out.println("\n>>> Test 20: Actualizando presupuesto " + nuevoPresupuesto.getNumero() + "...");
            nuevoPresupuesto.setDetalle("Service completo y cambio de cadena");
            filasAfectadas = presupuestoRepository.update(nuevoPresupuesto);
            if(filasAfectadas==1){
                System.out.println(" ## Presupuesto " + nuevoPresupuesto.getNumero() + " actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + nuevoPresupuesto);
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar el presupuesto !!");
            }

            //Test 21: Eliminar un presupuesto
            System.out.println("\n>>> Test 21: Eliminando presupuesto " + nuevoPresupuesto.getNumero()+ "...");
            filasAfectadasDelete = presupuestoRepository.delete(nuevoPresupuesto.getNumero());
            if(filasAfectadasDelete==1){
                System.out.println(" ## Presupuesto " + nuevoPresupuesto + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + presupuestoRepository.findByNumero(nuevoPresupuesto.getNumero()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el presupuesto !!");
            }

            //Test 22: Buscar presupuestos por bicicleta
            System.out.println("\n>>> Test 22: Buscando presupuesto por bicicleta...");
            List<Presupuesto> presupuestosBicicleta = presupuestoRepository.findByBicicleta(3);
            if(!presupuestosBicicleta.isEmpty()){
                System.out.println(" ## Presupuestos encontrados: " + presupuestosBicicleta.size());
                presupuestosBicicleta.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron presupuestos !!");
            }

            //Test 23: Buscar presupuestos por cliente
            System.out.println("\n>>> Test 23: Buscando presupuesto por cliente...");
            List<Presupuesto> presupuestosCliente = presupuestoRepository.findByCliente(3);
            if(!presupuestosCliente.isEmpty()){
                System.out.println(" ## Presupuestos encontrados: " + presupuestosCliente.size());
                presupuestosCliente.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron presupuestos !!");
            }


            //Pruebas para Repuesto

            //Test 24: Crear un nuevo repuesto
            System.out.println("\n>>> Test 24: Creando un repuesto");
            Repuesto nuevoRepuesto = new Repuesto(3232, "Stem 110", "3T", "Amarillo", 4000, 3000, 7);
            repuestoRepository.create(nuevoRepuesto);
            //acá no hice if de validación ya que no se genera automáticamente el código
            System.out.println(" ## Repuesto creado correctamente con el código " + nuevoRepuesto.getCodigo());
            System.out.println(nuevoRepuesto);

            //Test 25: Buscar repuesto por código (existente)
            System.out.println("\n>>> Test 25: Buscando presupuesto por código " + nuevoRepuesto.getCodigo() + "...");
            Repuesto repuestoEncontrado = repuestoRepository.findByCodigo(nuevoRepuesto.getCodigo());
            if(repuestoEncontrado!=null){
                System.out.println(" ## Repuesto encontrado: " + repuestoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el repuesto con el número " + nuevoRepuesto.getCodigo() + " !!");
            }

            //Test 26: Listar todos los repuestos
            System.out.println("\n>>> Test 26: Listando todos los repuestos...");
            List<Repuesto> repuestosTodos = repuestoRepository.findAll();            
            if(!repuestosTodos.isEmpty()){
                System.out.println(" ## Repuestos encontrados: " + repuestosTodos.size());
                repuestosTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron repuestos !!");
            }

            //Test 27: Actualizar un repuesto
            System.out.println("\n>>> Test 27: Actualizando repuesto " + nuevoRepuesto.getCodigo() + "...");
            nuevoRepuesto.setStock(10);
            filasAfectadas = repuestoRepository.update(nuevoRepuesto);
            if(filasAfectadas==1){
                System.out.println(" ## Repuesto " + nuevoRepuesto.getCodigo() + " actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + nuevoRepuesto);
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar el Repuesto !!");
            }

            //Test 28: Eliminar un repuesto
            System.out.println("\n>>> Test 28: Eliminando repuesto " + nuevoRepuesto.getCodigo() + "...");
            filasAfectadasDelete = repuestoRepository.delete(nuevoRepuesto.getCodigo());
            if(filasAfectadasDelete==1){
                System.out.println(" ## Repuesto " + nuevoRepuesto + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + repuestoRepository.findByCodigo(nuevoRepuesto.getCodigo()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el Repuesto !!");
            }

            //Test 29: Buscar repuestos en presupuestos
            System.out.println("\n>>> Test 29: Buscando repuesto por presupuesto...");
            List<Repuesto> repuestosPresupuesto = repuestoRepository.findByPresupuesto(1);
            if(!repuestosPresupuesto.isEmpty()){
                System.out.println(" ## Repuestos encontrados: " + repuestosPresupuesto.size());
                repuestosPresupuesto.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron repuestos !!");
            }


            //Pruebas para Detalle
            
            //Test 30: Crear un nuevo detalle
            System.out.println("\n>>> Test 30: Creando un detalle");
            Detalle nuevoDetalle = new Detalle(8, 116);
            if(presupuestoRepository.findByNumero(4)!=null && repuestoRepository.findByCodigo(116)!=null){ //acá otra validación para service
                detalleRepository.create(nuevoDetalle);
                System.out.println(" ## Detalle creado correctamente");
                System.out.println(nuevoDetalle);
            }else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el detalle !!");
            }
            
            //Test 31: Listar todos los detalles
            System.out.println("\n>>> Test 31: Listando todos los detalles...");
            List<Detalle> deatallesTodos = detalleRepository.findAll();           
            if(!deatallesTodos.isEmpty()){
                System.out.println(" ## Detalles encontrados: " + deatallesTodos.size());
                deatallesTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron detalles !!");
            }

            //Test 32: Buscar detalles por presupuesto
            System.out.println("\n>>> Test 32: Buscando detalle por presupuestos..");
            List<Detalle> detallesPresupuesto = detalleRepository.findByPresupuesto(1);
            if(!detallesPresupuesto.isEmpty()){
                System.out.println(" ## Detalles encontrados: " + detallesPresupuesto.size());
                detallesPresupuesto.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron detalles !!");
            }

            //Test 33: Buscar detalles por presupuesto
            System.out.println("\n>>> Test 33: Buscando detalle por repuestos..");
            List<Detalle> detallesRepuesto = detalleRepository.findByRepuesto(3005);
            if(!detallesRepuesto.isEmpty()){
                System.out.println(" ## Detalles encontrados: " + detallesRepuesto.size());
                detallesRepuesto.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron detalles !!");
            }


            //Test 34: Eliminar un detalle
            System.out.println("\n>>> Test 34: Eliminando detalle...");
            filasAfectadasDelete = detalleRepository.delete(1, 3005);
            if(filasAfectadasDelete==1){
                System.out.println(" ## Detalle eliminado correctamente");
                System.out.println("Verificando eliminación: " + detalleRepository.findByPresupuesto(1));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar el Detalle !!");
            }


                      
        } catch (Exception e) {
            System.err.println("¡¡ ERROR EN LA BASE DE DATOS !!");
            e.printStackTrace();
        }
    }
}
