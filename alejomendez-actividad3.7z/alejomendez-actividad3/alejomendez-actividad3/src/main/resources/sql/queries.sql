-- Cantidad de clientes y bicicletas que pasaron por el taller
SELECT      count(id) Cantidad, 'clientes' Tabla
FROM        clientes
UNION       
SELECT      count(id), 'bicicletas' Tabla
FROM        bicicletas;


-- Clientes que compraron repuestos
select		c.id 'cliente id', c.nombre, c.apellido, count(r.codigo) cantidad_repuestos
from		clientes c 
join		presupuestos p on c.id=p.cliente_id
join		detalles d on d.presupuesto_numero = p.numero
JOIN        repuestos r on r.codigo = d.repuesto_codigo
group by    c.id
order by    c.id;

-- Informar la suma total de las ventas del negocio por mes, ordenadas de mayor a menor.
select		year(fecha) año, month(fecha) mes, sum(valor_total) total_ventas_mes
from		presupuestos
group by	year(fecha), month(fecha)
order by	sum(valor_total) desc;

-- Informar cuáles son los repuestos vendidos por año
SELECT      year(p.fecha) año, r.producto, r.marca, r.color, count(r.codigo) 'cantidad vendida'
FROM        repuestos r
join        presupuestos p 
JOIN        detalles d on (d.presupuesto_numero, d.repuesto_codigo)=(p.numero, r.codigo)
group by    year(p.fecha), r.producto, r.marca, r.color
order by    año desc;

-- Listar todas las bicicletas que aún no salieron del taller
select      b.marca, b.modelo, b.color, b.rodado, b.fecha_ingreso
from        bicicletas b
WHERE       b.fecha_egreso is NULL;

-- Repuestos cuyo margen de ganancia es mayor a 40%
SELECT      r.codigo, r.producto, r.marca, r.color, (((r.precio_venta-r.precio_costo)/r.precio_costo)*100) Ganancia
FROM        repuestos r
WHERE       (((r.precio_venta-r.precio_costo)/r.precio_costo)*100) > 40
ORDER BY    Ganancia DESC;

-- Presupuestos en los cuales se haya vendido un manillar
SELECT      p.numero, p.fecha, p.bicicleta_id, r.producto
FROM        presupuestos p
join        detalles d on d.presupuesto_numero = p.numero
JOIN        repuestos r on r.codigo = d.repuesto_codigo
WHERE       r.producto like '%manillar%';

