package com.alejomendez.java.actividad3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlejomendezActividad3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
